# WanPE output schema

Use this structure for the boosted prompt. Fields in **bold** are required. Other fields are required when the content implies them (speech, music, VFX, product).

## Video-level header

Write as continuous prose, not a labeled spec sheet, in this order:

1. **Shot count** — `The video consists of N shots.`
2. **Medium + genre** — live-action cinematic / 2D picture-book / 3D Disney-esque / documentary handheld / cyberpunk montage / etc. Keep the user's medium.
3. **Content summary** — what happens, who is present, where, in what order. No new plot.
4. **Setting** — place, time of day, weather, era.
5. **Visual style** — palette, contrast, grain/texture, realism vs stylization.
6. **Narrative perspective** — whose body the camera mostly stays with; whether the viewer is observer, accomplice, or addressed.
7. **Pacing** — held / measured / accelerating / montage.
8. **Audio design** — speech yes/no, score yes/no and its register, diegetic bed, key SFX. State absences explicitly (`No score.` / `Speech only.`).

Do not dump these as a YAML list inside the prompt. Generators follow prose better when the header reads like a caption of a finished clip.

## Shot block

One block per shot. Timestamp format `[ss.ss-ee.ee s]` with two decimals. Shots must tile the duration with no overlap and no gap.

Each block should make all of the following recoverable:

| Field | What to write | Ban |
|---|---|---|
| Scale | extreme close-up / close-up / medium close-up / medium / medium-full / full / long / extreme long / two-shot / group / insert / OTS | "cinematic shot" with no scale |
| Angle | eye-level / low / high / top-down / Dutch / aerial | mood instead of angle |
| Lens feel | wide / normal / long-focus / anamorphic squeeze / shallow vs deep DOF | "beautiful bokeh" with no subject |
| Move | locked-off, handheld micro-sway, pan L/R, tilt, push-in, pull-out, track, orbit, crane, FPV, zoom (use zoom rarely) | "dynamic camera" |
| Subjects | named, with wardrobe and distinguishing marks the user gave | swapping who is in frame |
| Spatial relations | who is left/right/near/far, what the background is | floating the subject in a void |
| Actions | observable verbs in order, with speed and amplitude | emotion labels (`she looks sad`) |
| Lighting | source + direction + quality + color | "dramatic lighting" alone |
| Transition | cut / match cut / smash / dissolve / whip / hard cut on sound | unmotivated cut every 1s |
| Dialogue | `Name, tone, speed: "line"` | unlabeled lines |
| Sound this window | SFX and whether the score enters, swells, or drops | score described only in shot 1 then forgotten |

## Duration math

- First shot starts at `00.00`.
- Last shot ends at the target duration.
- Prefer slightly longer first and last shots over a string of 1-second cuts, unless the user asked for montage.
- A spoken sentence needs ~2–4s depending on length. Do not put two long lines in a 2s shot.

## Shot-count heuristic

| Duration | Default N | When to go lower | When to go higher |
|---|---|---|---|
| 5s | 1–2 | single gesture, product hero, portrait | two-beat joke |
| 10s | 2–4 | one continuous action | coverage of a conversation |
| 15s | 3–6 | long take requested | ad with product + face + pack |
| 30s | 4–8 | one location, one relationship | music video, fight, montage |

If granularity is `shot`, the user's N wins.

## Minimal legal example (schema only)

```
The video consists of 3 shots. Live-action, naturalistic indoor drama. A night-shift intern reheats leftovers in a glass-walled office corridor while her manager pauses out of sight; cool overhead fluorescents, measured pacing, speech and HVAC hum only, no score.

Shot 1 [00.00-04.00 s]:
Eye-level medium shot, locked-off, deep depth of field. A woman in a wrinkled oxford stands at a break-nook microwave. Cool overhead practicals. She taps the door glass once, then watches the carton turn. Hard cut.

Shot 2 [04.00-07.50 s]:
Over-the-shoulder medium from behind a darkened office door. The manager is a dark suit and a still shoulder in the foreground; the intern is sharp in the corridor beyond. He does not move. Corridor HVAC. Hard cut.

Shot 3 [07.50-10.00 s]:
Medium close-up, slow push-in, shallow depth of field. The intern opens the microwave, then freezes as she notices someone off-axis. She, under her breath, flat: "I wasn't complaining." Microwave beep. No score.
```
