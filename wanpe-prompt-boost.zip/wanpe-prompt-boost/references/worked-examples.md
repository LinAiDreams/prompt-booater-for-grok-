# Worked patterns

Structures only. Invent new content for the user's request. These show granularity handling and the reverse-construction habit.

## A. Intent-level (premise only)

User: `Cinematic realistic style, a company corridor at night, an intern working overtime complains and the boss overhears.`

What reverse construction adds — shot grammar, spatial split (intern in the lit corridor, boss in the dark office), speech binding, audio bed. What it must not add — a firing, a twist reveal that the intern is the boss's child, a score.

Pattern:

- Shot 1 holds the intern's mundane action (establishes overtime).
- Shot 2 withholds the boss as a foreground silhouette (overhearing is spatial, not explained).
- Shot 3 returns to the intern at the moment she realizes she is not alone (the turn is coverage, not new plot).

## B. Scene-level (event order given)

User: `A wandering monk sees a woman harassed in an alley, rushes in, fights the thugs with a bamboo flute, and gets her out.`

Keep the four beats in order. Do not add a second location. Camera can escalate (long take on the approach → handheld on the fight → steadier two-shot on the exit). The flute is a subject constraint — it must be visible as the weapon, not replaced by fists.

## C. Shot-level (user already directed)

User named four shots and two camera verbs. Complete lighting, wardrobe continuity, audio, and timestamps. Do not reorder. Do not "improve" a locked-off shot into a push-in.

## D. Speech-led

Budget time per line. One thought per shot unless it is a two-shot conversation. Write tone and speed. Keep ambience under the words. If the user supplied exact dialogue, the words in the boosted prompt are those words.

## E. Animation / picture-book

Header must name the animation medium and motion cadence (held drawings vs squash-and-stretch vs CG ease). Camera still uses real verbs; "cinematic 2D" is not a substitute for scale. Audio often speech-only in picture-book cases — do not sneak in a full orchestra unless asked.

## F. 30-second arena

This is where raw prompts collapse. Treat 30s as a short scene, not a longer caption.

- 5–8 shots, not 15.
- First 3s must already contain a readable subject and a camera decision.
- Mid-clip is development (a second scale, a second piece of information), not a new genre.
- Final shot pays off a constraint from shot 1 (same object, same doorway, same line of eyeline).
- Audio has an arc (enter, hold, drop) instead of one sentence of "epic music."

## G. Product / ad

Hero object is a subject. It must be identifiable in at least two shots. Do not invent claims. If a logo is requested, give it a timestamped insert or pack-out. Lighting describes how the product is seen (soft bounce, rim, practical), not "premium vibes."
