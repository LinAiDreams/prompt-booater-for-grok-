# SC-GRPO fidelity checklist

WanPE's Semantic-Consistency GRPO scores an enhanced plan `y` against the user request `x` on nine dimensions. Run this after drafting. Repair any fail before delivery.

Compatible elaboration is a pass. Omission, substitution, rebinding, and temporal contradiction are fails.

## How to run it

1. List `C(x)` as atomic constraints (one subject, one action, one line, one camera verb, one style word, one negative).
2. For each dimension below, mark Pass / Soft / Fail.
3. Soft = the constraint is present but thin (e.g., rain is mentioned, wet-ground behavior is not). Thicken; do not treat Soft as license to invent plot.
4. Fail = a constraint is gone, swapped, or contradicted. Rewrite that field, then rescan all nine — fixes create new contradictions.

## Nine dimensions

### 1. Style
Must keep requested medium, genre, palette, and realism level.
- Fail — user said 2D picture-book, plan is live-action photoreal.
- Fail — user said "no film grain," plan adds 35mm grain.
- Pass — user said "cinematic realistic," plan names eye-level coverage, motivated practicals, restrained palette.

### 2. Subjects
Every named person, animal, object, brand, or wardrobe item survives with the same identity.
- Fail — "intern and boss" becomes "two coworkers."
- Fail — a specified red coat becomes a black coat.
- Pass — adding a microwave because the intern is reheating food the user already implied.

### 3. Actions
User-stated actions keep order, agency, and outcome.
- Fail — user order is walk → notice → fight; plan fights first.
- Fail — "climbs the trunk" becomes "stands beside the tree."
- Pass — splitting "climbs" into reach, pull, and plant across two shots.

### 4. Dialogue
Lines, speaker binding, language, and tone.
- Fail — line given to the wrong person.
- Fail — line rewritten into a different meaning.
- Fail — user asked for speech, plan is silent.
- Pass — small rhythm polish that keeps the words (`You still know to come back.` stays that sentence).

### 5. Sound
Speech / score / SFX / silence as requested.
- Fail — user said speech-only; plan adds an orchestral swell.
- Fail — user named a flute fight; plan has generic whooshes and no flute.
- Pass — adding HVAC hum under office speech when the user did not forbid ambience.

### 6. Camera
Every camera verb the user wrote is executed. New moves are allowed only when granularity is `intent` or `scene` and they do not cancel a stated verb.
- Fail — user said "locked-off"; plan orbits.
- Fail — user said "camera pushes in on shot 3"; push-in is missing.
- Pass — adding a short track on an unspecified shot to hold a walk.

### 7. Lighting
Keep named sources, time of day, and quality.
- Fail — "overcast daylight" becomes golden-hour rim.
- Fail — user forbade neon; plan is cyberpunk signage.
- Pass — describing fixture type when the user only said "office night."

### 8. Spatial relations
Keep layout, who is near whom, foreground / background, interior vs exterior.
- Fail — "behind the door, watching the corridor" becomes a two-shot side by side.
- Fail — rooftop requested, alley delivered.
- Pass — specifying left/right when the user only said "over-the-shoulder."

### 9. Scene
Keep place, time, era, weather, and the event envelope.
- Fail — blueberry farm becomes an orchard.
- Fail — "historical court" becomes modern office.
- Pass — naming corridor glass and fluorescent temperature from "company corridor at night."

## Cross-shot consistency (always scan)

After the nine, check the plan as a sequence:

- The same character does not change wardrobe, age, or species across shots unless the user asked for a transformation.
- Lighting continuity matches time of day unless a cut jumps time on purpose.
- Audio mix does not teleport (score cannot vanish for one shot and return with no editorial reason).
- Inserts and cutaways return to a geography that still makes sense.
- Timestamps cover the full duration once.

## Refusal notes

If the user request is internally impossible (locked-off and orbit in the same named shot, speech-only and "big choir"), keep the earlier / more specific constraint, state the conflict in Director notes, and do not silently pick the prettier option.
