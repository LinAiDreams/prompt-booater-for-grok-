# Format adapters

Write the plan in WanPE native form first. Only then retarget. Adaptation changes layout and keyword dialect, not facts, bindings, or timestamps.

If the user did not name a model, deliver native form.

## Wan / Wan3 / Tongyi Wanxiang

Native form is already close. Keep:

- `The video consists of N shots.`
- Timestamped `Shot k [ss.ss-ee.ee s]:` blocks.
- Combined picture + sound in the same prompt.
- Explicit `No score` / `Speech only` when needed.

Optional header nouns Wan models respond to — shot size, camera angle, lens, light source, color tone. Do not add a separate JSON `shot_type` field unless the user's API still requires it.

## Seedance

Keep multi-shot timestamps. Lead with coverage verbs Seedance follows reliably (track, push-in, locked-off, orbit). Put dialogue in-shot, not in a preface. If the user wants 30s, do not collapse to a single paragraph — Seedance is strongest when the plan already budgets the half-minute.

## Veo

Prefer a short global look paragraph, then shot blocks. Veo likes continuous physical causality — write how weight shifts, how cloth and hair react, how a hand enters frame. Avoid stacked style tags. Name the audio bed; Veo will invent a score if you stay silent and the user did not want one.

## Kling

Shorter shot sentences. One primary move per shot. Name scale every shot. Kling drops trailing clauses, so put subject + action + camera in the first two sentences of each block. Keep dialogue lines short.

## Sora

Prose can be slightly longer and more sensory, but still shot-blocked. Sora hallucinates extra cuts if you list too many clauses without timestamps — keep N conservative. State what must not change across the cut (wardrobe, setting, time of day).

## LTX

LTX native enhancers are format-sensitive. After the native plan is done, flatten each shot into a compact caption line:

`[timestamp] [scale] [move] [subject action] [light] [audio]`

Do not drop timestamp or scale. Do not add LTX-only control tokens unless the user supplied them.

## Runway

Runway clips are often shorter. If target duration exceeds the selected model's cap, split the same plan into sequential clips with a continuity line at the top of clip 2+ (`continues from previous clip, same wardrobe, same corridor, night`). Never rewrite identity between clips.

## MiniMax / Hailuo

Hailuo follows dense single-block prompts. Keep the header + shots, but make each shot one tight paragraph. Put the audio mix in the header and only mention SFX that start or stop inside a shot.

## Adaptation checklist

After retargeting:

- Shot count unchanged.
- Every `C(x)` item still present.
- Dialogue still speaker-bound.
- Duration sum unchanged.
- No new characters, locations, or plot beats.
